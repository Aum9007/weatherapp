import 'package:flutter/material.dart';

void main() {
  runApp(weather());
}
class weather extends StatefulWidget {
  @override
  _weatherState createState() => _weatherState();
}

class _weatherState extends State<weather> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: homepage(),
    );
  }
}
class homepage extends StatefulWidget {
  @override
  _homepageState createState() => _homepageState();
}

class _homepageState extends State<homepage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:Text(
          "Weather App",
          style: TextStyle(
            fontSize: 20.0
          ),
        )
      ),
      body: Container(
        child: Column(
          children: [
            FlatButton(
              onPressed: (){},
              child: Text(
                "see"
              ),
            )
          ],
        ),
      ),
    );
  }
}

