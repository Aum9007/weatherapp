package com.example.myweather

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
